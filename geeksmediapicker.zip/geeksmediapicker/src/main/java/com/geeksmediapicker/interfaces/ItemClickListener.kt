package com.geeksmediapicker.interfaces

interface ItemClickListener {
    fun onClick(position: Int, event: Any? = null)
}
