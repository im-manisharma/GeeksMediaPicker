package com.geeksmediapicker

object GeeksMediaType {
    const val IMAGE = "IMAGE"
    const val VIDEO = "VIDEO"
}